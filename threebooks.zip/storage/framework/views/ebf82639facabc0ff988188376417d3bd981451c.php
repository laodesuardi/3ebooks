<?php $__env->startComponent('mail::message'); ?>
# Terima Kasih

Terima kasih sudah memasukan data, tunggu beberapa saat, link download akan dikirim ke nomor whatsapp anda....

<?php $__env->startComponent('mail::button', ['url' => 'https://bit.ly/3cII0tx']); ?>
Kirim pesan
<?php echo $__env->renderComponent(); ?>

Terima kasih,<br>
<?php echo e(config('app.nama')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\aplications\email\resources\views/emails/email.blade.php ENDPATH**/ ?>