<?php $__env->startComponent('mail::message'); ?>
# Three Ebooks

Terima kasih sudah memasukan data, tunggu beberapa saat, link download akan dikirim ke nomor whatsapp anda....

Apabila anda belum menerima link download, klik tombol dibawah ini.
<?php $__env->startComponent('mail::button', ['url' => 'https://api.whatsapp.com/send?phone=6285159997927&text=Hallo%20kak,%20saya%20belum%20menerima%20ebooknya.']); ?>
Kirim pesan
<?php echo $__env->renderComponent(); ?>

Terima kasih,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\aplications\threebooks\resources\views/emails/email.blade.php ENDPATH**/ ?>