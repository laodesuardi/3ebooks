<?php echo e($slot); ?>

<?php /**PATH D:\aplications\tiga-ebook\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>