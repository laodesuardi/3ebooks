





<?php $__env->startSection('container'); ?>
  

  <div class="container bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded relative" id="box-alert" role="alert">    
    <span class="block sm:inline">Terima kasih sudah memasukan data, tunggu beberapa saat, link download akan dikirim ke nomor whatsapp anda...</span>
  </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\aplications\threebooks\resources\views//thanks/index.blade.php ENDPATH**/ ?>