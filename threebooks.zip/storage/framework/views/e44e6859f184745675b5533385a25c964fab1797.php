<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tembus Target Jualan Online</title>
    
    
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
  </head>
  <body>
    
      <div class="container mt-4">
        <?php echo $__env->yieldContent('container'); ?>
      </div>
  
    
     <script src="public/js/script.js"></script> 
  </body>
</html><?php /**PATH D:\aplications\tiga-ebook\resources\views/layouts/main.blade.php ENDPATH**/ ?>